# pehal.ai GitHub Pages Deployment Guide

## What's Been Updated ✅

### Theme Changes
- **Color Scheme**: Dark blue (#1e3a8a, #2d5a9e), white, and black
- **Removed**: All AI-generated emojis (rockets, computers, targets, etc.)
- **Look & Feel**: Professional, clean, enterprise-grade appearance
- **Inspired by**: aishwarya.ai design aesthetic

### Link Structure
- **All pages now work locally** - no Claude.ai redirects
- **Navigation**: index.html → interactive-platform.html → marketplace-demo.html, etc.
- **No login required** - fully accessible without authentication

### Files Updated
1. ✅ `index.html` - Master hub page (dark blue theme)
2. ✅ `interactive-platform.html` - Full platform demo (no emojis)
3. ✅ `homepage-landing.html` - Role-based landing (professional)
4. ✅ `homepage-dark.html` - Dark blue theme (refined)
5. ✅ `marketplace-demo.html` - Solutions marketplace (no emojis)

---

## Deploy to GitHub Pages

### Option 1: GitHub Web UI (Easiest)

1. Go to your GitHub repo: `https://github.com/yourusername/pehal-ai`
2. Click **Settings** (top right)
3. Click **Pages** (left sidebar)
4. Under **Source**:
   - Branch: `main`
   - Folder: `/ (root)`
5. Click **Save**
6. Wait 1-2 minutes
7. Your site is live at: `https://yourusername.github.io/pehal-ai/`

### Option 2: Command Line (Git)

```bash
cd ~/pehal-ai
git add .
git commit -m "Update theme to dark blue, remove emojis, fix links"
git push origin main
```

---

## Test Your Site

### Check If It's Working
- Visit: `https://yourusername.github.io/pehal-ai/`
- Click around all demo buttons
- Verify colors are dark blue (not purple)
- Verify no emoji icons appear

### Troubleshooting

**Problem: 404 error**
- Wait 2-3 minutes after deployment
- Clear browser cache (Ctrl+Shift+Delete)
- Verify all HTML files are in the repo root

**Problem: Styles not loading**
- Hard refresh: `Ctrl+Shift+R` (Windows/Linux) or `Cmd+Shift+R` (Mac)
- Check browser console for errors (F12)

**Problem: Links broken**
- Ensure file names are exactly: `index.html`, `interactive-platform.html`, etc.
- All links should be relative paths, not absolute URLs

---

## File Structure

```
pehal-ai/
├── index.html                      (Master hub)
├── interactive-platform.html       (Platform demo)
├── homepage-landing.html           (Landing page)
├── homepage-dark.html              (Dark blue design)
├── marketplace-demo.html           (Solutions)
├── README.md
└── GITHUB_PAGES_DEPLOY.md          (This file)
```

---

## Color Palette

### Dark Blue Theme
- **Background**: `#0a0e27` (Deep navy)
- **Cards**: `#141b35` (Dark blue)
- **Primary Blue**: `#1e3a8a` (Medium blue)
- **Accent Blue**: `#2d5a9e` (Bright blue)
- **Text Light**: `#b0b8d4` (Light gray-blue)
- **Text Dark**: `#8892b0` (Medium gray-blue)
- **Text Primary**: `#ffffff` (White)

---

## Custom Domain (Optional)

To use a custom domain (e.g., `pehal.ai`):

1. Go to **Settings** → **Pages**
2. Under **Custom domain**, enter: `pehal.ai`
3. Update your domain registrar DNS settings:
   - Add GitHub's nameservers OR
   - Create CNAME record pointing to: `yourusername.github.io`
4. GitHub will auto-generate HTTPS certificate

---

## Next Steps

1. ✅ Deploy to GitHub Pages (Steps above)
2. ✅ Test all pages and links
3. ✅ Share the URL with stakeholders
4. ⏭️ Optional: Add analytics (Google Analytics, Plausible)
5. ⏭️ Optional: Custom domain setup
6. ⏭️ Optional: Add more demo pages or update copy

---

## Support

- **GitHub Pages Docs**: https://pages.github.com/
- **GitHub Issues**: Create an issue in your repo
- **Verify site status**: Visit https://status.github.com/

---

**pehal.ai** | AI Agent Marketplace & Governance Platform  
© 2026 | All rights reserved
