# pehal.ai - AI Agent Marketplace & Governance Platform

🚀 **Deploy AI agents in days, not months.**

A modern, open-source platform connecting enterprises with vetted architects through an intelligent marketplace.

---

## 🌐 Live Website

**Main Hub:** https://yourusername.github.io/pehal-ai/

Or explore specific demos:
- 💻 **Interactive Platform:** `/interactive-platform.html`
- 🎯 **Role-Based Landing:** `/homepage-landing.html`
- 🌙 **Dark Blue Theme:** `/homepage-dark.html`
- 🏪 **Marketplace Demo:** `/marketplace-demo.html`

---

## 📋 About pehal.ai

pehal.ai is a B2B2C platform that simplifies AI agent deployment through:

### **5 Core Services**

1. **Intelligent Problem Intake & Recommendations**
   - Free tier: Business problem → AI recommendations
   - Pro tier ($1.5-3.5K): Custom governance + consultation
   - Enterprise tier ($5-15K+): Dedicated support

2. **Freelancer Matching Engine**
   - Algorithmic matching (skills, experience, availability)
   - Top 3-5 vetted architects per intake
   - Competitive bidding

3. **Freelancer Registration & Buddy Program**
   - Self-service onboarding
   - AgentFlow Academy (3 learning pathways)
   - 10-week mentorship program

4. **Community & Revenue Sharing**
   - 50-80% revenue split for freelancers
   - Zero DevOps overhead
   - Passive income from marketplace

5. **Containerized Solutions Marketplace**
   - Pre-built, production-ready agents
   - 6+ solutions (Customer Service, Invoice Processing, Fraud Detection, etc.)
   - 2-week deployment, 99.9% uptime SLA

---

## 🎯 Platform Features

| Feature | Description |
|---------|-------------|
| **AI-Powered Intake** | Transform business problems into actionable roadmaps |
| **Freelancer Marketplace** | Connect with 50+ vetted architects |
| **Pre-Built Solutions** | Deploy in 2 weeks with full support |
| **Governance Frameworks** | Industry-specific compliance templates |
| **Revenue Sharing** | 50-80% for freelancers, 20-50% for platform |
| **Community** | Forums, buddy program, mentorship |

---

## 📊 Business Model

### Revenue Streams (Year 1)
- **Advisory Services:** $15K (intakes + consultation)
- **Transaction Commissions:** $34K (20% on services)
- **Infrastructure Margin:** $72K (10-15% on compute)
- **Support Contracts:** $20K (ongoing support)
- **IP Licensing:** $5K (governance templates)

**Total Year 1:** ~$146K  
**Year 2 Projection:** $1.2M  
**Year 3 Projection:** $3.1M

### Growth Path
- **Months 0-3:** MVP + Beta (5 freelancers, 10 intakes)
- **Months 4-6:** PMF (First deals, customer feedback)
- **Months 7-12:** Scale (50+ freelancers, 20+ clients)
- **Year 2:** Profitability (100+ freelancers, 50+ clients)
- **Year 3:** Market leader (200+ freelancers, 100+ clients)

---

## 🛠️ Technology Stack

**Frontend:**
- HTML5, CSS3, JavaScript
- React (interactive components)
- Responsive design (mobile-first)

**Backend (Future):**
- .NET 8 / Node.js
- Azure OpenAI (GPT-4)
- PostgreSQL / Cosmos DB

**Cloud:**
- Microsoft Azure (primary)
- AWS, Google Cloud (multi-cloud)
- Docker, Kubernetes

**DevOps:**
- GitHub Actions (CI/CD)
- Terraform (IaC)
- Azure Container Registry

---

## 📁 File Structure

```
pehal-ai/
├── index.html                    # Main hub/landing page
├── interactive-platform.html     # Full platform demo
├── homepage-landing.html         # Role-based landing
├── homepage-dark.html            # Dark blue theme
├── marketplace-demo.html         # Marketplace showcase
├── README.md                      # This file
├── DEPLOYMENT.md                 # Deployment guide
└── assets/                       # (For future use)
    ├── css/
    ├── js/
    └── images/
```

---

## 🚀 Quick Start

### **View the Website Locally**

1. Clone this repo:
```bash
git clone https://github.com/yourusername/pehal-ai.git
cd pehal-ai
```

2. Open in browser:
```bash
# macOS
open index.html

# Windows
start index.html

# Linux
firefox index.html
```

3. Navigate through pages using the interface

### **Deploy on GitHub Pages**

1. Push to GitHub
2. Go to **Settings** → **Pages**
3. Select `main` branch / `root` folder
4. Site published at: `https://yourusername.github.io/pehal-ai/`

---

## 💡 Features & Navigation

### **Main Hub (index.html)**
- Overview of entire platform
- Links to all 4 demo sites
- Platform features showcase
- Tech stack display
- Call-to-action buttons

### **Interactive Platform (interactive-platform.html)**
- Full working prototype
- Intake form simulation
- Freelancer bidding interface
- Marketplace browser
- Profile management
- All navigation tabs

### **Role-Based Landing (homepage-landing.html)**
- Separate paths for customers & freelancers
- Professional branding
- Value propositions
- Feature highlights
- Numbered feature cards

### **Dark Blue Theme (homepage-dark.html)**
- Modern dark aesthetic
- Interactive Q&A section
- Avatar mascots
- Smooth animations
- Contemporary gradients

### **Marketplace Demo (marketplace-demo.html)**
- Tabbed interface
- 6 pre-built solutions
- Freelancer profiles
- Economics & projections
- Success stories

---

## 🔧 Customization

### **Update Links**
Edit `index.html` to point to your custom domain:
```html
<a href="https://pehal-ai.vercel.app/...">
→ Replace with your URL
```

### **Add Your Branding**
Modify in any HTML file:
```html
<h1>pehal.ai</h1> → <h1>Your Company Name</h1>
```

### **Change Colors**
CSS variables (in `<style>` tags):
```css
#667eea → Your primary color
#764ba2 → Your secondary color
#1a1a1a → Your text color
```

---

## 📈 Analytics & Tracking

### **Add Google Analytics**
1. Create property at [google.com/analytics](https://google.com/analytics)
2. Get Tracking ID: `G-XXXXXXXX`
3. Add to `<head>` of each HTML file:
```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXX');
</script>
```

### **Monitor Traffic**
- GitHub provides basic visitor stats
- Google Analytics for detailed insights
- GitHub Pages dashboard (Settings → Pages)

---

## 🌍 Deploy to Custom Domain

### **Option 1: Use GitHub Pages (Free)**
1. Buy domain ($5-15/year)
2. Point DNS to GitHub:
   - A Records: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - CNAME: `www` → `yourusername.github.io`
3. In repo Settings → Pages → Add custom domain
4. Enable HTTPS

### **Option 2: Use Vercel (Free)**
```bash
npm install -g vercel
vercel
# Result: pehal-ai.vercel.app
```

### **Option 3: Use Netlify (Free)**
```bash
npm install -g netlify-cli
netlify deploy --prod --dir=.
# Result: pehal-ai.netlify.app
```

---

## 🛡️ Security & Performance

✅ **SSL/TLS:** Auto-enabled on GitHub Pages  
✅ **CDN:** Global content delivery network  
✅ **Uptime:** 99.9% GitHub infrastructure  
✅ **Caching:** Browser & edge caching  
✅ **Performance:** Optimized for mobile & desktop  

---

## 📞 Support & Feedback

- **Issues:** [GitHub Issues](https://github.com/yourusername/pehal-ai/issues)
- **Discussions:** [GitHub Discussions](https://github.com/yourusername/pehal-ai/discussions)
- **Email:** your@email.com
- **Twitter:** [@pehal_ai](https://twitter.com/pehal_ai)

---

## 📄 License

This project is open source and available under the MIT License.

---

## 🙏 Contributors

Built with ❤️ for the AI community.

---

**🚀 Ready to deploy AI agents? Start at the [main hub](index.html) →**

---

*Last Updated: October 2026*
